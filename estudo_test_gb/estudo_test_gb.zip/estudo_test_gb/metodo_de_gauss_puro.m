clc
clear all
A = [2 3 -1; 4 4 -3; 2 -3 1];
B = [5; 3; -1];

R = A\B